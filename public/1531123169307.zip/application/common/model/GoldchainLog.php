<?php

namespace app\common\model;

use think\Model;

class GoldchainLog extends Model
{
    protected $autoWriteTimestamp = true;
}
