<?php

namespace app\common\model;

use think\Model;

class GoldchainDaysum extends Model
{
    //
}
