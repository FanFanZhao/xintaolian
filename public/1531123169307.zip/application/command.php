<?php

return [
    'app\common\command\Recognize',
];
