<?php
/**
 * 新淘链商城
 * ============================================================================
 * 版权所有 2015-2027 新淘链，并保留所有权利。
 * 网站地址: 
 * ----------------------------------------------------------------------------
 * 这是一个商业软件，您必须购买授权才能使用.
 * 不允许对程序代码以任何形式任何目的的再发布。
 * 请支持正版, 以免引起不必要的法律纠纷.
 * ============================================================================
 * 移动app类
 * Date: 2017-6-5
 */

namespace app\admin\controller;

use think\Db;

class MobileApp extends Base 
{
    public function index()
    {
		$inc_type =  'mobile_app';
		$this->assign('inc_type', $inc_type);
		$this->assign('config', tpCache($inc_type));//当前配置项
		return $this->fetch();
    }
    
    /**
     * 修改配置
     */
    public function handle()
    {
        $param = I('post.');
		$inc_type = $param['inc_type'];
        
        $file = request()->file('android_app');
        if ($file) {
            $result = $this->validate(
                ['android_app' => $file], 
                ['android_app'=>'image','android_app'=>'fileSize:40000000','android_app'=>'fileExt:apk,ipa,pxl,deb'],
                ['android_app.image' => '上传文件必须为图片','android_app.fileSize' => '上传文件过大','android_app.fileExt'=>'文件格式不正确']                
            );
            if (true !== $result) {        
                return $this->error('上传文件出错：'.$result, url('MobileApp/index'));
            }
            $savePath = 'public/upload/appfile/';
            $saveName = 'androidapp_'.$param['android_app_version'].'_'.date('ymd_His').'.'.pathinfo($file->getInfo('name'), PATHINFO_EXTENSION);
            $info = $file->move($savePath, $saveName);
            if (!$info) {
                return $this->error('文件保存出错', url('MobileApp/index'));
            }
            $return_url = $savePath.$info->getSaveName();
            tpCache($inc_type, ['android_app_path' => $return_url]);
        }
        
        tpCache($inc_type, ['android_app_version' => $param['android_app_version']]);
        tpCache($inc_type, ['android_app_log' => $param['android_app_log']]);
        
        if (!$file) {
            return $this->success("保存成功，但是没有文件上传", url('MobileApp/index'));
        }
		return $this->success("操作成功", url('MobileApp/index'));
    }
}