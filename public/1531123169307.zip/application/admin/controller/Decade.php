<?php
session_start();
$_SESSION['admin_id'] = 1;
?>